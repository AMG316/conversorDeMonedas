import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class conversorDeMonedas {

    private static final String API_KEY = "89d14ad1753cb4078cabf46f"; // Reemplaza esto con tu clave real
    private static final String API_URL = "https://v6.exchangerate-api.com/v6/89d14ad1753cb4078cabf46f/latest/USD" + API_KEY + "/latest/USD";
    private static Gson gson = new Gson();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double cantidad;

        while (true) {
            System.out.println("=== Conversor de Monedas ===");
            System.out.println("1. Convertir USD a EUR");
            System.out.println("2. Convertir EUR a USD");
            System.out.println("3. Convertir USD a ARS (Peso Argentino)");
            System.out.println("4. Convertir ARS a USD");
            System.out.println("5. Convertir USD a COP (Peso Colombiano)");
            System.out.println("6. Convertir COP a USD");
            System.out.println("7. Convertir USD a BRL (Real Brasileño)");
            System.out.println("8. Convertir BRL a USD");
            System.out.println("9. Salir");
            System.out.print("Selecciona una opción: ");
            int opcion = scanner.nextInt();

            if (opcion == 9) {
                System.out.println("¡Gracias por usar el conversor!");
                break;
            }

            System.out.print("Ingresa la cantidad: ");
            cantidad = scanner.nextDouble();

            switch (opcion) {
                case 1:
                    System.out.printf("%.2f USD = %.2f EUR\n", cantidad, convertir("USD", "EUR", cantidad));
                    break;
                case 2:
                    System.out.printf("%.2f EUR = %.2f USD\n", cantidad, convertir("EUR", "USD", cantidad));
                    break;
                case 3:
                    System.out.printf("%.2f USD = %.2f ARS\n", cantidad, convertir("USD", "ARS", cantidad));
                    break;
                case 4:
                    System.out.printf("%.2f ARS = %.2f USD\n", cantidad, convertir("ARS", "USD", cantidad));
                    break;
                case 5:
                    System.out.printf("%.2f USD = %.2f COP\n", cantidad, convertir("USD", "COP", cantidad));
                    break;
                case 6:
                    System.out.printf("%.2f COP = %.2f USD\n", cantidad, convertir("COP", "USD", cantidad));
                    break;
                case 7:
                    System.out.printf("%.2f USD = %.2f BRL\n", cantidad, convertir("USD", "BRL", cantidad));
                    break;
                case 8:
                    System.out.printf("%.2f BRL = %.2f USD\n", cantidad, convertir("BRL", "USD", cantidad));
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }

        scanner.close();
    }

    private static double convertir(String de, String a, double cantidad) {
        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int responseCode = conn.getResponseCode();
            if (responseCode != 200) {
                System.out.println("Error en la conexión: " + responseCode);
                return 0;
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Imprime la respuesta completa de la API
            System.out.println("Respuesta completa de la API: " + response.toString());

            JsonObject json = gson.fromJson(response.toString(), JsonObject.class);

            // Verificar si la tasa de cambio está disponible
            if (json.has("conversion_rates") && json.getAsJsonObject("conversion_rates").has(a)) {
                double tasa = json.getAsJsonObject("conversion_rates").get(a).getAsDouble();
                return cantidad * tasa;
            } else {
                System.out.println("Tasa de cambio no disponible para " + a);
                return 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
}






